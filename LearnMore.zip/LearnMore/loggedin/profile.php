<?php
  session_start();
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 <meta name="viewport" content="width=device-width, initial-scale=1">

 <link rel="stylesheet" href="../style.css">
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
 integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
 <link rel="stylesheet" href="styleprofile.css">


 <title>LearnMore</title>
 </head>
  <body>
    <div class="topnav" id="myTopnav">
    <a href="../loggedin.php" class="active">Home</a>
        <?php
        if (isset($_SESSION['userId'])){
          echo '<a href="../loggedin/profile.php" name="profile">Profile</a>
                <a href="../includes/logout.inc.php" name="logout-submit">SIGN OUT</a>';
        }
         ?>
       </div>
  </header>
  <?php
  try{
    $db=new PDO('mysql:host=localhost;dbname=loginsystemtut;charset=utf8','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
  }
  catch(Exception $err){
    die('Connection Failed :'.$err->getMessage());
  }

  $req=$db->prepare('SELECT * FROM users WHERE emailUsers=:e');
  $req->execute(array('e'=>$_SESSION['userEmail']));
  if($enreg=$req->fetch()){/*If we find the person with the login email*/
    $id=$enreg['idUsers'];
    $req2=$db->query("SELECT * FROM imgupload WHERE userid='$id'");
    while($rowImg=$req2->fetch()){
      echo '<div class="wrapper">
      <div class="profile-card js-profile-card">
          <div class="profile-card__img">';
      if ($rowImg['status']==0){
        echo "<img src='../uploads/profile".$id.".jpg?".mt_rand()."' alt='profile pic'>";
      }else{
        echo "<img src='../uploads/profiledefault.jpg' alt='default profile pic'>";
      }
      echo '</div>';
    }
  }
   ?>
   <div class="profile-card__cnt js-profile-cnt">
        <div class="profile-card__name"><?php echo isset($_SESSION['userUid']) ? $_SESSION['userUid']: '';?></div>
        <div class="profile-card__txt"><strong>ID: </strong><?php echo isset($_SESSION['userId']) ? $_SESSION['userId'] : '';?></div>
        <div class="profile-card__txt"><strong>Email: </strong><?php echo isset($_SESSION['userEmail']) ? $_SESSION['userEmail'] : '';?></div>

    
    
  </center>

<?php require "../footer.php"; ?>
